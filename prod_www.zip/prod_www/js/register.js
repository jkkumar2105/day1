$(document).ready(function(){
     $.formUtils.addValidator({
        name : 'username',
        validatorFunction : function(value, $el, config, language, $form) {
            value = value.toLowerCase();
           
	     // Commented by Arvind 	           
            //if (value.indexOf('_') == 0 || value.indexOf('.') == 0 || value.indexOf('-') == 0) {
            //    return false;
           // }
            var pattern = /^[a-zA-Z_0-9-\.\_\-\s]+$/;
            
            if (pattern.test(value) == false) {
                //document.getElementsByName("user_id").className = 'buttonErrorNew';   
               document.getElementById("MyformErrDtls").style.display = 'block';
                //document.getElementById("divUsr2").style.color  = 'red';
                document.getElementById("imgdivUsr2").src = 'images/icon-fail.png';
                document.getElementById("divUsr2").className = 'err_valgrp';
                return false;
            }
            document.getElementById("imgdivUsr2").src = 'images/icon-ok.png';
            document.getElementById("divUsr2").className = 'nrm_valgrp';
             
            return true;
        },
        //errorMessage : 'The user name must be between 6-64 characters and include only letters, numbers and can include but not begin with: �` ~ = ^ ; : | . - _',
        errorMessage : '',
        errorMessageKey: 'badUsernameHW'
    });
     
     //Added new function to validate userID length 
     $.formUtils.addValidator({
        name : 'username_length',
        validatorFunction : function(value, $el, config, language, $form) {
            value = value.toLowerCase();
            //alert(value.length);
            if (value.length < 6 ) {
               document.getElementById("MyformErrDtls").style.display = 'block';
               document.getElementById("divUsr1").style.color = 'red';
               document.getElementById("imgdivUsr1").src = 'images/icon-fail.png';
                return false;
               }
             if (value.length > 63 ) {
               document.getElementById("MyformErrDtls").style.display = 'block';
               document.getElementById("divUsr1").style.color = 'red';
               document.getElementById("imgdivUsr1").src = 'images/icon-fail.png';
                return false;
               }  
            document.getElementById("divUsr1").style.color = 'green';
            document.getElementById("imgdivUsr1").src = 'images/icon-ok.png';
            return true;
        },
        errorMessage : '',
        errorMessageKey: 'badUsername'
    });
     
    $.formUtils.addValidator({
        name : 'username_honey',
        validatorFunction : function(value, $el, config, language, $form) {
            value = value.toLowerCase();
    
            if (value.indexOf('honeywell') != -1 || value.indexOf('honey') != -1 || value.indexOf('allied') != -1) {
               document.getElementById("divUsr4").style.color = 'red';
               document.getElementById("MyformErrDtls").style.display = 'block';
               document.getElementById("imgdivUsr4").src = 'images/icon-fail.png';
               validUsr = false;
                return false;
            }
            document.getElementById("divUsr4").style.color = 'green';
            document.getElementById("imgdivUsr4").src = 'images/icon-ok.png';
            return true;
        },
        errorMessage : '',
        errorMessageKey: 'badUsername'
    });
    //Added new function to validate spaces for UserID
     $.formUtils.addValidator({
        name : 'username_Spaces', 
         validatorFunction : function(value, $el, config, language, $form) {
            value = value.toLowerCase();
            var pattern = /\s+/;
            //return !value.match(pattern);
            if (pattern.test(value) == true)
            {
               document.getElementById("divUsr3").style.color = 'red';
               document.getElementById("MyformErrDtls").style.display = 'block';
               document.getElementById("imgdivUsr3").src = 'images/icon-fail.png';
               return false
            }
               else { document.getElementById("divUsr3").style.color = 'green';
            document.getElementById("imgdivUsr3").src = 'images/icon-ok.png';
             return true;
               
            }
        },
        errorMessage : '',
        errorMessageKey: 'noSpaceField'
    });
     
     
    
     $.formUtils.addValidator({
        name : 'username_chkFirstLetter', 
         validatorFunction : function(value, $el, config, language, $form) {
            value = value.toLowerCase();
          
            if (value.indexOf('_') == 0 || value.indexOf('.') == 0 || value.indexOf('-') == 0) {
               document.getElementById("divUsr7").style.color = 'red';
               document.getElementById("MyformErrDtls").style.display = 'block';
               document.getElementById("imgdivUsr7").src = 'images/icon-fail.png';
               return false
            }
               else { document.getElementById("divUsr7").style.color = 'green';
            document.getElementById("imgdivUsr7").src = 'images/icon-ok.png';
             return true;
               }
            
           
        },
        errorMessage : '',
        errorMessageKey: 'noSpaceField'
    });
    // Validate consecutive underscores
    $.formUtils.addValidator({
        name : 'username_Undr', 
         validatorFunction : function(value, $el, config, language, $form) {
            value = value.toLowerCase();
            //var pattern = /^((?!__).)*$/;
            var pattern = /^((?!__|--).)*$/; 
            if (pattern.test(value) == false)
            {
               document.getElementById("divUsr3").style.color = 'red';
               document.getElementById("MyformErrDtls").style.display = 'block';
               document.getElementById("imgdivUsr3").src = 'images/icon-fail.png';
                return false;
            }
               else { document.getElementById("divUsr3").style.color = 'green';
            document.getElementById("imgdivUsr3").src = 'images/icon-ok.png';
             return true;
               
            }
        },
        errorMessage : '',
        errorMessageKey: 'noSpaceField'
    });
    
    // Validate the single letters followed by number
    $.formUtils.addValidator({
        name : 'username_sequence', 
        validatorFunction : function(value, $el, config, language, $form) {
            value = value.toLowerCase();
            var pattern = /^[a-z,A-Z]{1}[0-9]{1,}/i;
            //alert(pattern.test(value))
             if (pattern.test(value) == true) {
                document.getElementById("divUsr5").style.color  = 'red';
                document.getElementById("MyformErrDtls").style.display = 'block';
                document.getElementById("imgdivUsr5").src = 'images/icon-fail.png';
                validUsr = false;
                return false;
            }
            document.getElementById("divUsr5").style.color  = 'green';
            document.getElementById("imgdivUsr5").src = 'images/icon-ok.png';
            return true;
        },
        errorMessage : '',
        errorMessageKey: 'badUsernameSeq'
    });

    $.formUtils.addValidator({
        name : 'nospace',
        validatorFunction : function(value, $el, config, language, $form) {
            value = value.toLowerCase();
            var pattern = /\s/;
            return !value.match(pattern);
        },
        errorMessage : 'This field cannot contain spaces',
        errorMessageKey: 'noSpaceField'
    });
    
    $.formUtils.addValidator({
        name : 'honeywell_email',
        validatorFunction : function(value, $el, config, language, $form) {
            value = value.toLowerCase();
            if (value.indexOf('honeywell') != -1 || value.indexOf('allied') != -1) {
                return false;
            }
            return true;
        },
        errorMessage : 'You have used a Honeywell.com address which is  not authorized.',
        errorMessageKey: 'badHoneywellEmail'
    });
    
    $.formUtils.addValidator({
        name : 'no_email',
        validatorFunction : function(value, $el, config, language, $form) {
            value = value.toLowerCase();
            var extensions = [".com", ".net", ".org", ".edu", "_com", "_net", "_org", "_edu", "-com", "-net", "-org", "-edu"];
            var i = 0, count = extensions.length;
            for(i = 0; i < count; i++) {
                if (value.indexOf(extensions[i]) != -1) {
                    document.getElementById("divUsr6").style.color  = 'red';
                document.getElementById("MyformErrDtls").style.display = 'block';
                document.getElementById("imgdivUsr6").src = 'images/icon-fail.png';
                    
                    return false;
                }
            }
               document.getElementById("divUsr6").style.color = 'green';
               document.getElementById("imgdivUsr6").src = 'images/icon-ok.png';
            return true;
        },
        errorMessage : '',
        errorMessageKey: 'badLikeEmail'
    });
    //Added to validate password length
     $.formUtils.addValidator({
        name : 'pwd_length',
        validatorFunction : function(value, $el, config, language, $form) {
            value = value.toLowerCase();
            //alert(value.length);
            if (value.length < 8 ) {
               document.getElementById("MyPwdDtls").style.display = 'block';
               document.getElementById("dvPwdDtls1").style.color = 'red';
               document.getElementById("imgPwdDtls1").src = 'images/icon-fail.png';
                return false;
               }
               if (value.length > 55) {
               document.getElementById("MyPwdDtls").style.display = 'block';
               document.getElementById("dvPwdDtls1").style.color = 'red';
               document.getElementById("imgPwdDtls1").src = 'images/icon-fail.png';
                return false;
               }
            document.getElementById("dvPwdDtls1").style.color = 'green';
            document.getElementById("imgPwdDtls1").src = 'images/icon-ok.png';
            return true;
        },
        errorMessage : '',
        errorMessageKey: 'badUsername'
    });
    //Added to validate password strength
    $.formUtils.addValidator({
        name : 'pwd_Strngth', 
         validatorFunction : function(value, $el, config, language, $form) {
          var passwordStrength=0;
          var minMaxLength = /^[\s\S]{8,32}$/,
               upper = /[A-Z]/,
               lower = /[a-z]/,
               number = /[0-9]/,
               special = /[ !"#$%&'()*+,\-./:;<=>?@[\\\]^_`{|}~]/;
        if (number.test(value)) {
           passwordStrength = passwordStrength +1;          
        }
        if (upper.test(value)){
          passwordStrength = passwordStrength +1;          
        }
        if (lower.test(value)){
          passwordStrength = passwordStrength +1;         
        }
        if (special.test(value)){
          passwordStrength = passwordStrength +1;          
        }
        if (passwordStrength < 3 ) {          
              document.getElementById("MyPwdDtls").style.display = 'block';
              document.getElementById("dvPwdDtls2").style.color = 'red';
              document.getElementById("imgPwdDtls2").src = 'images/icon-fail.png';
              return false;
        }
          else{
               document.getElementById("dvPwdDtls2").style.color = 'green';
               document.getElementById("imgPwdDtls2").src = 'images/icon-ok.png';
            return true;               
            }
        },
        errorMessage : '',
        errorMessageKey: 'noSpaceField'
    });
    
    //Added function to validate repeated characters for passwrod field
     $.formUtils.addValidator({
        name : 'pwd_RepeatdChar',
        validatorFunction : function(value, $el, config, language, $form) {
            var password = $('input[name="password"]').val();
             var userId = $('input[name="user_id"]').val();
               var bValid=true; 
               var NameValues = tokenize(userId," "," ",true);
               
	  	for(var i=0;i<password.length-2;i++)
	  	{
	  		var substr = password.substring(i,i+3);
                        //alert(substr);
	  		for(var j=0;j<NameValues.length;j++)
	  		{
                         //alert(NameValues[j].indexOf(substr));

	  			if(NameValues[j].indexOf(substr)!=-1)
	  			{
	  				bValid=false;	  				
	  			}
	  		}
                }
               if (!bValid) {
                       document.getElementById("MyPwdDtls").style.display = 'block';
               document.getElementById("dvPwdDtls3").style.color = 'red';
               document.getElementById("imgPwdDtls3").src = 'images/icon-fail.png';
                   return false; 
                    //code
               }
            document.getElementById("dvPwdDtls3").style.color = 'green';
            document.getElementById("imgPwdDtls3").src = 'images/icon-ok.png';
            
               //document.getElementById("MyformErrDtls").style.display = 'none';
               return true;
            //return password == value;
        },
        errorMessage : '',
        errorMessageKey: ''
    });
    
    $.formUtils.addValidator({
        name : 'email_confirmation',
        validatorFunction : function(value, $el, config, language, $form) {
            var email = $('input[name="email"]').val();

            return email == value;
        },
        errorMessage : 'Email addresses do not match',
        errorMessageKey: 'badEmailMatch'
    });
    
    $.formUtils.addValidator({
        name : 'pass_confirm',
        validatorFunction : function(value, $el, config, language, $form) {
            var password = $('input[name="password"]').val();

            return password == value;
        },
        errorMessage : 'Passwords do not match',
        errorMessageKey: 'badPasswordMatch'
    });
    
    $.formUtils.addValidator({
        name : 'validate_phone',
        validatorFunction : function(value, $el, config, language, $form) {
            var pattern = /[a-zA-Z]/g;
            return pattern.test(value) == false;
        },
        errorMessage : 'Cannot contain letters',
        errorMessageKey: 'badPhoneNumber'
    });
    
    
    $.validate({
        modules: 'location, date, security'
    });    
      $.formUtils.addValidator({
        name : 'check_country',
        validatorFunction : function (value, $el, config, language, $form) {
            if (value == 0) { 
                return false;
               
            }else {
                return true;
            }
        },
        errorMessage : 'Please select a country',
        errorMessageKey : 'wrongCity'
    });
      
       $.formUtils.addValidator({
        name : 'check_question1',
        validatorFunction : function (value, $el, config, language, $form) {
          debugger;
            if (value == "") { 
                return true;
               
            }else {
                return false;
            }
        },
        errorMessage : 'Please select 1st question',
        errorMessageKey : 'wrongCity'
    });
       
       $.formUtils.addValidator({
        name : 'check_question2',
        validatorFunction : function (value, $el, config, language, $form) {
          debugger;
            if (value == "") { 
                return true;
               
            }else {
                return false;
            }
        },
        errorMessage : 'Please select 2nd question',
        errorMessageKey : 'wrongCity'
    });
       
       $.formUtils.addValidator({
        name : 'check_question3',
        validatorFunction : function (value, $el, config, language, $form) {
            if (value == "") { 
                return true;
               
            }else {
                return false;
            }
        },
        errorMessage : 'Please select 3rd question',
        errorMessageKey : 'wrongCity'
    });
      
      $.formUtils.addValidator({
        name : 'check_validcountry',
        validatorFunction : function (value, $el, config, language, $form) {
            if (value == "IR" || value ==  "CU" || value == "KP" || value == "SY" || value=="SD") {
               alert("You are not allowed to access this application.")
                return false;
            }else {
                return true;
            }
        },
        errorMessage : 'Country restriction',
        errorMessageKey : 'wrongCity'
    });
})

// Validate the userid and send the array 
 function tokenize(str,separator,trim,ignoreEmptyTokens)
{
     //alert(str);
     var start = 0;
     var end = 0;
     var token = new Array();
     var input = String(str);
     for(var i=0; i<input.length+1; i++)
       {
       	  var flag="false";
       	  var tempStr="";
          if(input.slice(start, i).indexOf(separator) != -1)
            {
               end = i - separator.length;
               tempStr = input.slice(start, end);
               if(tempStr.indexOf(",")==-1)
               		token[token.length] = tempStr;
               start = i;
               flag = "true";
            }
          else
            {
               if(i == input.length)
               {
                 tempStr = input.slice(start);
                 token[token.length] = tempStr;
                 flag = "true";
               }
            }
            if(flag=="true")
            {
            var startTemp=0;
            var endTemp =0;
            for(var j=0;j<tempStr.length+1;j++)
            {
	            if(tempStr.slice(0, j).indexOf(",") != -1)
	            {
	               endTemp = j - 1;
	               token[token.length] = tempStr.slice(startTemp, endTemp);
	               startTemp = j;
	            }
	            else
	            {
	               if(i == tempStr.length)
	                 token[token.length] = tempStr.slice(startTemp);
	            }
            }
            }
       }

    if(trim)
      for(var i=0; i<token.length; i++)
        {
          while(token[i].slice(0, trim.length) == trim)
            token[i] = token[i].slice(trim.length);
          while(token[i].slice(token[i].length-trim.length) == trim)
            token[i] = token[i].slice(0, token[i].length-trim.length);
        }

    var finalToken = new Array();
    if(ignoreEmptyTokens)
      {
         for(var i=0; i<token.length; i++)
           if(token[i] != "")
             finalToken[finalToken.length] = token[i];
      }
    else
      {
         finalToken = token;
      }

     return finalToken;
  }

// Hide user details section on focus changed
function fnHideUsrdtls() {      
       document.getElementById("MyformErrDtls").style.display = 'none';
}
// Hide user details section on focus changed
function fnHidePwddtls() { 
            document.getElementById("MyPwdDtls").style.display = 'none';
}
