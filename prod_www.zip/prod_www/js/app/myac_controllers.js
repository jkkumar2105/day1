// MAIN VIEW
pilotsApp.controller('MainCtrl', ['$scope', '$rootScope', '$location', function($scope, $rootScope, $location) {
    $rootScope.pageTitle = 'Pilot Gateway';

    $scope.$on('$viewContentLoaded', function() {
        $scope.setContentSize();
    });
    $scope.setContentSize = function(){
        var hdrHeight = ($('.hdr_bar').height() + 5) + 'px';
        $('.content_view').css({top: hdrHeight});

        var ftrHeight = $rootScope.hideFooter ? 0 : $('.ftr_bar').height();
        var bnrHeight = $('#HoneywellEUCookie-Banner').is(':visible') ? $('#HoneywellEUCookie-Banner').height() + 15 : 0;

        var btmHeight = (ftrHeight + bnrHeight) + 'px';
        
        $('.content_view').css({bottom: btmHeight});
        $('.side_menu').css({top: hdrHeight, bottom: btmHeight});
        
        $('#HoneywellEUCookie-CookieDismiss').on('click', function() {
            btmHeight = (ftrHeight) + 'px';
            $('.content_view').css({bottom: btmHeight});
            $('.side_menu').css({bottom: btmHeight});
        });
    };

    $('#HoneywellEUCookie-Banner' ).bind('DOMNodeInserted', function() {
        $scope.setContentSize(false);
    });
    
    $scope.$on('$routeChangeStart', function(next, current) {
        $scope.activeTab();
    });
    
    $scope.goBack = function() {
        $('iframe').remove();

        window.history.back();
    };

    $scope.activeTab = function() {
        $('.tab_btn').each(function(){
            var link = $(this).attr('data-link');
            
            if (window.location.hash.indexOf(link) === 1) {
                $scope.changeTab($(this));
            }
        });
    };

    $scope.tabClick = function($event) {
        $event.preventDefault();

        var $target = $($event.delegateTarget);
        
        $scope.changeTab($target);
           
        var url = $target.attr('data-link');
        
        if (url === '/myac/') {
            var fmsid=$.cookie('fmsid'), modelid=$.cookie('modelid');
            if (fmsid) {
                url += 'aircraft/' + fmsid + '/' + modelid; 
            } 
        }
        
        $location.path(url);
    };
    
    $scope.changeTab = function($target) {
         if ($target.hasClass('active') === false && $target.hasClass('disabled') === false) {
            var img = $('.tab_btn.active').removeClass('active').find('img');
            var imgSrc = img.attr('src');
            imgSrc = imgSrc.replace('_active', '');
            img.attr('src', imgSrc);
            
            img = $target.addClass('active').find('img');
            imgSrc = img.attr('src');
            imgSrc = imgSrc.replace('.png', '_active.png');
            img.attr('src', imgSrc);
        }
    };
    
}]);

//HOME VIEW
pilotsApp.controller('HomeViewCtrl', ['$scope', '$rootScope', 'Slides', '$location', 'Slider', function($scope, $rootScope, Slides, $location, Slider) {
    $rootScope.pageTitle = 'Pilot Gateway';
        
    if ($('.isloading-overlay').is(':visible')) {
        $.isLoading('hide');
    }

    $scope.slides = [];
    $scope.params = {};
    $scope.params.itemid = '{EDAD2487-AB41-4CC9-9FD8-7366D5107403}';
    
    $scope.load_slides = function() {
        Slides.query($scope.params, function (data) {
            if (data.length > 0) {
                $scope.numStaticSlides = 1;
                $scope.slides = data;
                // Commented by Arvind to fix the login double click issue
                //setTimeout(function () {
                //    if (Slider.slider) {
                //        Slider.slider.reloadSlider();
                //    }                  
                ///},1000);
            }
        });
    };
    
    $scope.doLogin = function() {
        var user = $('#login_form_userid').val(), pword = $('#login_form_pword').val();
        if (user.length === 0 || pword.length === 0) {
            alert('Please verify Username and Password are properly filled in');
        } else {
            $scope.login(user, pword);
        }
    };
    
    $scope.doRegister = function() {
            //window.open("#/myac/register", '_self',false);
	    $location.path('/myac/register/');    
    };

    $scope.doModalLogin = function() {
        debugger;
        var user = $('#login_modal_userid').val(), pword = $('#login_modal_pword').val();
        $scope.login(user, pword);
    };
    
    $scope.login = function(user, pword) {        
        if(user !== '' && pword !== '')
        {
	debugger;
            $.isLoading({ text: 'Logging In', position:   'overlay' });

            var loginData = {
                'username': user,
                'password': pword
            };
            
            $.ajax({
                url: baseUrl + 'services/pilotsapp.svc/login',
                type: "POST",
                data: loginData,
                xhrFields: {
                    withCredentials: true
                },
                crossDomain: true,
                success: function(data, status, jqXHR){
                    $.isLoading('hide');
                    
                    if (data.Status === 'Error') {
                        alert(data.Message);
                    } else {
                        $.cookie('honeywellid', data.Payload.UserId, { expires: 1, path: '/' });

                        var isEulaAccepted = $.jStorage.get("EULA");

                        if( isEulaAccepted ) {
                            var today = new Date();
                            //today = new Date("04/19/2015");
                            $.jStorage.set("lastLoginTime", +new Date(today.getMonth() + 1 + "/" + today.getDate() + "/" + today.getFullYear()));
                            var fmsid=$.cookie('fmsid'), modelid=$.cookie('modelid');
                            if (fmsid) {
                                $location.path('/myac/aircraft/' + fmsid + '/' + modelid);
                            } else {
                                $location.path('/myac/makes/');
                            }
                        } else {
                            $location.path("/eula/0");
                        }


                        $scope.$apply();
                    }
                }
            });
        } else {
            alert("Please verify Username and Password are properly filled in");
        }
    };

    $scope.load_slides();
    
    ga('send', 'pageview', { 'page': $location.path(), 'title': $rootScope.pageTitle  });
}]);

//REGISTER VIEW
pilotsApp.controller('RegisterViewCtrl', ['$location','$scope', '$rootScope', 'SecurityQuestions', 'vcRecaptchaService',  function($location,$scope, $rootScope, SecurityQuestions, vcRecaptchaService) {
    $rootScope.pageTitle = 'Registration';
     $rootScope.breadcrumbTitle = 'Back';
    $scope.questions = [];
    $scope.load_questions = function() {
        SecurityQuestions.query({}, function (data) {
            if (data.length > 0) {
                $scope.questions = data;
            }
        }, function (data) {
        });
    };
    
    $('.security_dropdown').on('change', function() {
        var selectedQuestions = [];
        var selectedOptions = $('.security_dropdown').find('option:selected');
        
        for (var i = 0; i < selectedOptions.length; i++) {
            selectedQuestions.push($(selectedOptions[i]).val());
        }
        
        $('.security_dropdown option').removeAttr('disabled');
        $('.security_dropdown option').each(function() {
             for (var i = 0; i < selectedQuestions.length; i++) {
                if (selectedQuestions[i] == $(this).val()) {
                    $(this).attr('disabled', 'disabled');
                }
             }
        });
    });
    
    $scope.submitForm = function($event){
        $event.preventDefault();
        var registrationValid = $('#register_form').isValid();
        
        if (registrationValid === true) {
            $.isLoading({ text: 'Registering User', position:   'overlay' });
            
            var disabled = $('#register_form').find('option:disabled').removeAttr('disabled');
            var postData = $('#register_form').serializeArray();
            disabled.attr('disabled','disabled');
            
            $.ajax({
                url: baseUrl + 'services/pilotsapp.svc/register',
                type: "POST",
                data: postData,
                xhrFields: {
                    withCredentials: true
                },
                success: function(data){
                    $.isLoading('hide');
                    
                    if (data.Status === 'Error') {
                        alert(data.Message);
                    } else {
                        ga('send', 'event', 'Registrations', 'Submit Form', '');
                        $location.path('/myac/register/thanks/');
                        $scope = $scope || angular.element(document).scope();
                        if(!$scope.$$phase) {
                            $scope.$apply();
                        }
                    }
                }
            });
        } else {
            alert('Please verify all information is correct and mandatory fields are completed and resubmit the form');
        }
    };
    
    $scope.load_questions();
    
    ga('send', 'pageview', { 'page': $location.path(), 'title': $rootScope.pageTitle });
}]);

//LOGOUT VIEW
pilotsApp.controller('LogoutViewCtrl', ['$scope', '$rootScope', '$location', function($scope, $rootScope, $location) {
    $rootScope.pageTitle = 'Logging Out';

    $.isLoading({ text: 'Logging Out', position:   'overlay' });

    $.get(baseUrl + 'services/pilotsapp.svc/removeusersession', function(data){
        $.isLoading('hide');
        if (data.Status === 'Error') {
            alert(data.Message);
        } else {
            $.cookie('honeywellid', null);

            $scope.$apply(function()
            {
                $rootScope.user.needsAuthentication = true;
                $location.path('/myac/');
            });    
        }
    }, "JSON");

    ga('send', 'pageview', { 'page': $location.path(), 'title': $rootScope.pageTitle });
}]);

//GENERIC CONTENT VIEW
pilotsApp.controller('ContentViewCtrl', ['$scope', '$location', '$rootScope', function($scope, $location, $rootScope) {
    ga('send', 'pageview', { 'page': $location.path(), 'title': $rootScope.pageTitle});
}]);

//MAKES VIEW
pilotsApp.controller('MakesViewCtrl', ['$scope', '$rootScope', '$location', 'Makes', function($scope, $rootScope, $location, Makes) {
    $rootScope.pageTitle = 'Step 1 of 3';
    $rootScope.selectingAircraft = true;
    $rootScope.unreadMessagesCount = 0;
    
    $.isLoading({ text: 'Loading', position:   'overlay' });

    $scope.makes = [];
    $scope.load_makes = function() {
        Makes.query({}, function (data) {
            if (data.length > 0 && data[0].Status != "Error") {
                $scope.makes = data;
            }

            $.isLoading('hide');
        }, function (data) {
            $.isLoading('hide');
            alert('Failed to load Resources, Please try again.');
        });
    };
    
    $scope.selectMake = function(make) {
        ga('send', 'event', 'Aircraft', 'Select Make', make.name);
        //Added by Arvind for Breadcrumb navigation
         $rootScope.selManufacturer = make.name;
        $location.path('/myac/models/' + make.id);
    };
    //Added new function by Arvind for Back Navigation
    $scope.setGoback = function(make) {
         if ($rootScope.breadcrumbTitle == undefined)
         {  $rootScope.showLogo = true
         } else
            {
                $rootScope.showLogo = false;
                $rootScope.breadcrumbTitle="Back";
                }
    };    
    $scope.selectOther = function() {
        ga('send', 'event', 'Aircraft', 'Select Make', 'Other');
        $location.path('/myac/aircraft/');
    };

    $scope.load_makes();
    $scope.setGoback();
    ga('send', 'pageview', { 'page': $location.path(), 'title': $rootScope.pageTitle });
}]);

//MODELS VIEW
pilotsApp.controller('ModelsViewCtrl', ['$scope', '$rootScope', '$routeParams', '$location', 'Models', function($scope, $rootScope, $routeParam, $location, Models) {
    $rootScope.pageTitle = 'Step 2 of 3';
    //Added by Arvind
    $rootScope.breadcrumbTitle = $rootScope.selManufacturer;
    $rootScope.unreadMessagesCount = 0;

    $.isLoading({ text: 'Loading', position:   'overlay' });

    $scope.models = [];
    $scope.params = {};
    $scope.params.itemid = $routeParam.makeid;
    
    $scope.load_models = function() {
        Models.query($scope.params, function (data) {
            if (data.length > 0 && data[0].Status != "Error") {
                $scope.models = data;
            }

            $.isLoading('hide');
        }, function (data) {
            $.isLoading('hide');
            alert('Failed to load Resources, Please try again.');
        });
    };
    
    $scope.selectModel = function(model) {
        ga('send', 'event', 'Aircraft', 'Select Model', model.name);
         $rootScope.selModel =  model.name;
        $location.path('/myac/fms/' + model.id);
    };
    
    $scope.load_models();
    
    ga('send', 'pageview', { 'page': $location.path(), 'title': $rootScope.pageTitle });
}]);

//FMS VIEW
pilotsApp.controller('FMSViewCtrl', ['$scope', '$rootScope', '$routeParams', '$location', 'FMS', function($scope, $rootScope, $routeParam, $location, FMS) {
    $rootScope.pageTitle = 'Step 3 of 3';
    //Added by Arvind
    $rootScope.breadcrumbTitle = $rootScope.selModel,
    $scope.versions = [];
    $scope.params = {};
    $scope.params.itemid = $routeParam.modelid;
    $rootScope.unreadMessagesCount = 0;

    $scope.load_fms = function() {
        $.isLoading({ text: 'Loading', position:   'overlay' });

        FMS.query($scope.params, function (data) {
            if (data.length > 0 && data[0].Status != "Error") {
                $scope.versions = data;
            }

            $.isLoading('hide');
        }, function (data) {
            $.isLoading('hide');
            alert('Failed to load Resources, Please try again.');
        });
    };

    $scope.selectFMS = function(id) {
        $location.path('/myac/aircraft/' + id + '/' + $routeParam.modelid + '/');
        $scope = $scope || angular.element(document).scope();
        if(!$scope.$$phase) {
            $scope.$apply();
        }
    };

    $scope.load_fms();

    ga('send', 'pageview', { 'page': $location.path(), 'title': $rootScope.pageTitle });
}]);

//AIRCRAFT VIEW
pilotsApp.controller('AircraftViewCtrl', ['$scope', '$rootScope', '$routeParams', 'Aircraft', '$location', function($scope, $rootScope, $routeParam, Aircraft, $location) {
    $rootScope.pageTitle = 'My Aircraft';
    
    $.isLoading({ text: 'Loading', position:   'overlay' });

    $.cookie('fmsid', $routeParam.fmsid, { expires: 7, path: '/' });
    $.cookie('modelid', $routeParam.modelid, { expires: 7, path: '/' });

    $scope.make = {};
    $scope.model = {};
    $scope.fms = {};
    $rootScope.unreadMessagesCount = 0;

    $scope.params = {};
    $scope.params.itemid = $routeParam.fmsid != 'other' ? $routeParam.fmsid : null;
    $scope.params.modelId = $routeParam.modelid;

    $scope.load_aircraft = function() {
        Aircraft.query($scope.params, function (data) {
            if (data.length > 0 && data[0].Status === "Error") {
                $.isLoading('hide');
            } else {
                $scope.make = data.make !== null ? data.make : {};
                $scope.model = data.model !== null ? data.model : {};
                $scope.fms = data.fms !== null ? data.fms : {};

                var title = $scope.make.name + ' - ' + $scope.model.name + ' - ' + $scope.fms.name;
                //Added by Arvind
		if ( $scope.fms.name != undefined) {
                    //code  
                    $rootScope.breadcrumbTitle = $scope.fms.name;
                     $rootScope.selFMS =  $scope.fms.name ;
                } else {$rootScope.breadcrumbTitle = 'Back';
                $rootScope.selFMS =  'I Dont Know';}
                

                if ( $.jStorage.get('lastLoginTime') ) {
                    for( var sectionIndex in $scope.fms.children ){
                        var section = $scope.fms.children[sectionIndex];
                        for( var subsectionIndex in section.children ){
                            var subsectionDocs = section.children[subsectionIndex].documents || section.children[subsectionIndex].children || {};
                            for( var documentIndex in subsectionDocs ){
                                if( !$.jStorage.get(subsectionDocs[documentIndex].id) ){
                                    var documentUpdatedTime = subsectionDocs[documentIndex].revisiondate || subsectionDocs[documentIndex].publishdate;

                                    if ( documentUpdatedTime && +(new Date(documentUpdatedTime)) >= $.jStorage.get('lastLoginTime') ) {
                                        console.log(documentUpdatedTime);
                                        $rootScope.unreadMessagesCount++;
                                    }
                                }
                            }
                        }
                    }
                }

                ga('send', 'pageview', { 'page': $location.path(), 'title': title });

                $rootScope.selectingAircraft = true;
    
                if ($rootScope.selectingAircraft && $rootScope.selectingAircraft === true) {
                    var honeywellId = $.cookie('honeywellid');
                    if (honeywellId && data.make && data.model) {
                        $rootScope.selectingAircraft = false;
                        var contactAircraftRecord = {
                            'honeywellId': honeywellId,
                            'make': data.make.name,
                            'model': data.model.name,
                            'fms': data.fms.name
                        };

                        $.ajax({
                            url: baseUrl + 'services/pilotsapp.svc/sfcontact',
                            type: "POST",
                            data: contactAircraftRecord,
                            xhrFields: {
                                withCredentials: true
                            }
                        });
                    }
                }

                $.isLoading('hide');
            }

        }, function (data) {
            $.isLoading('hide');
            alert('Failed to load Resources, Please try again.');
        });
    };
    
    $scope.changeAircraft = function() {
        $rootScope.breadcrumbTitle = 'Back';
        $.cookie('fmsid', null);
        $.cookie('modelid', null);
        $location.path('/myac/makes/');
    };
    //Added by Arvind to sort the document by publish date
    $scope.sortByPublishedDate = function($event) {
        //alert(1);
        //debugger;
        //return -new Date(document.publishdate);        
        if ($event.revisiondate != undefined) {
        var drevision = new Date($event.revisiondate); 
        var dpublished= new Date($event.publishdate);
            if (drevision > dpublished) {
                return -new Date($event.revisiondate)
            }
            else{
                return -new Date($event.publishdate)                
            }            
        }
        else { return -new Date($event.publishdate) }
    };
    //Added by Arvind to return the image class
    $scope.binddocumentclass = function(doctype, docstatus) {
       // debugger;
       if(doctype=="SIL" && docstatus ==false)
            return "silunread"
        else if(doctype=="SIL" && docstatus==true)
         return "silread"
        else if(doctype=="Brochure" && docstatus==false)
         return "famunread";
        else if(doctype=="Brochure" && docstatus==true)
         return "famread";
        else if(doctype==undefined && docstatus==false)
         return "otherdocunread";      
        else if(doctype==undefined && docstatus==true)
         return "otherdocread";
        else
         return "otherdocunread";  
        
    };
    
    $scope.toggleDrawer = function($event) {
        var $this = $($event.target);
        if ($this.hasClass('open')) {
            $this.next('ul').slideUp();
            $this.removeClass('open');
        } else {
            $this.next('ul').slideDown();
            $this.addClass('open');
        }
    };

    $scope.load_aircraft();
    
    ga('send', 'pageview', { 'page': $location.path(), 'title': $rootScope.pageTitle });
}]);

//SEARCH VIEW
pilotsApp.controller('SearchViewCtrl', ['$scope', '$location', '$rootScope', '$routeParams', 'Search',  function ($scope, $location, $rootScope, $routeParams, Search) {
    $rootScope.pageTitle = 'Search Results';
    
    if ($routeParams.query) {
        $scope.results = null;
        
        $scope.do_search = function() {
            $.isLoading({ text: 'Searching', position:   'overlay' });
            
            $scope.params = {};
            $scope.params.keyword = $routeParams.query;
            
            Search.query($scope.params, function (data) {
                if (data.length > 0 && data[0].Status != "Error") {
                    $scope.results = data;
                }
    
                $.isLoading('hide');
            }, function (data) {
                $.isLoading('hide');
                alert('Failed to find items that match criteria, Please search again.');
            });
        };
        
        $scope.do_search();
    } else {
        $scope.emptyQuery = true;
    }
    
    var searchTerms = $routeParams.query ? $routeParams.query : '';
    ga('send', 'pageview', { 'page': $location.path(), 'title': $rootScope.pageTitle + ' - ' + searchTerms });
}]);
