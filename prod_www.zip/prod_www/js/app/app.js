'use strict';

// PilotsApp.svc Bindings
var contentServices = angular.module('contentServices', ['ngResource']);

// Declare app level module which depends on filters, and services
var pilotsApp = angular.module('pilotsApp', ['ngSanitize', 'ngTouch', 'ngRoute', 'ngAnimate', 'contentServices', 'vcRecaptcha'])
    .directive('sideMenu', function() {
        return {
            templateUrl: '/templates/side-menu.html'
        };
    }).directive('searchBox', [ function () {
        return {
            restrict: 'E',
            templateUrl: '/templates/search-box.html',
            replace: true,
            controller: [ '$scope', '$location', function ($scope, $location) {
                $scope.search = function(query) {
                    if (typeof(query) === 'undefined') {
                        $location.path("/myac/search/");
                    } else {
                        $location.path("/myac/search/"+encodeURIComponent(query));
                    }
                }
            }]
        }
    }]).directive('formLoaded', [ function () {
        return {
            restrict: 'A',
            link: function (scope, ele, attrs) {
                if (scope.$last === true) {
                    $('input').placeholder();
                    $('textarea').placeholder();
                }
            }
        }
    }]).filter('formField', ['$sce', function($sce) {
        return function(inputObj) {
            var type = inputObj.fieldtype.toLowerCase();
            var name = inputObj.name.toLowerCase().split(' ').join('_');
            var required = inputObj.required === '1';
            var placeholder = inputObj.placeholdertext ? inputObj.placeholdertext : "";
            var buffer = '';
            
            if (type === 'text') {
                buffer = '<label for="' + name + '">';
                buffer += required ? '<span class="req">*</span>' : '';
                buffer += inputObj.name + ':</label><input placeholder="' + placeholder +  '" name="' + name + (required ? '" data-validation="required"' : '"') + ' type="text">';
            } else if (type === 'phone') {
                buffer = '<label for="' + name + '">';
                buffer += required ? '<span class="req">*</span>' : '';
                buffer += inputObj.name + ':</label><input placeholder="' + placeholder +  '" name="' + name + (required ? '" data-validation="required validate_phone"' : '" data-validation="validate_phone"') + ' type="tel">';
            } else if (type === 'email') {
                buffer = '<label for="' + name + '">';
                buffer += required ? '<span class="req">*</span>' : '';
                buffer += inputObj.name + ':</label><input placeholder="' + placeholder +  '" name="' + name + (required ? '" data-validation="email required"' : '"') + ' type="email">';
            } else if (type === 'text area') {
                buffer = '<label for="' + name + '">';
                buffer += required ? '<span class="req">*</span>' : '';
                buffer += inputObj.name + ':</label><textarea placeholder="' + placeholder +  '" name="' + name + (required ? '" data-validation="required"' : '"') + '></textarea>';
            } else if (type === 'file') {
                buffer = '<label for="' + name + '">';
                buffer += required ? '<span class="req">*</span>' : '';
                buffer += inputObj.name + ':</label><img class="hide clear_btn" src="/images/btn_cancel_red.png" onclick="clearFileUpload(\'' + name + '\')" >';
                buffer += '<input name="' + name + (required ? '" data-validation="required size"' : '" data-validation="size"') + ' type="file" data-validation-max-size="5M"><br/>';
            } else if (type === 'dropdown') {
                buffer = '<label for="' + name + '">';
                buffer += required ? '<span class="req">*</span>' : '';
                buffer += inputObj.name + ':</label>';
            }
            
            return $sce.trustAsHtml(buffer);
        };
    }]).config(['$httpProvider', function ($httpProvider) {
        $httpProvider.defaults.withCredentials = true;
    }]);
    
    
pilotsApp.run(['$rootScope', '$location', 'AuthService',  function($rootScope, $location, AuthService) {
    $rootScope.pageTitle = 'Pilot Gateway';
    $rootScope.selectingAircraft = false;

    $rootScope.$on("$routeChangeStart", function (event, current, previous) {

        //Show/Hide logo or footer from routes attribute
        $rootScope.showLogo     = current.showLogo;
        $rootScope.hideLogoText = current.hideLogoText;
        $rootScope.hideFooter   = current.hideFooter;
                
        if ((current.requireLogin || current.controller == 'HomeViewCtrl') && current != previous ) {
            var userNeedsAuth = false;
    
            AuthService.needsAuthentication().then(function(data){
                userNeedsAuth = data;
                
                if(userNeedsAuth == false && current.controller == 'HomeViewCtrl') {
                    var honeywellid = $.cookie('honeywellid'), fmsid=$.cookie('fmsid'), modelid=$.cookie('modelid');
                    if (honeywellid) {
                        if (fmsid) {
                            $location.path('/myac/aircraft/' + fmsid + '/' + modelid); 
                        } else {
                            $location.path('/myac/makes/'); 
                        }
                    }
                } else if (userNeedsAuth && current.controler != 'HomeViewCtrl') {
                    $location.path('/myac/');
                }
            });
        }
    });

    $rootScope.$on("$routeChangeSuccess", function (event, current, previous) {
        if (current.pageTitle) {
            $rootScope.pageTitle = current.pageTitle;
        }
    });
}]);  