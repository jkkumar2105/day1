angular.module('pilotsApp').factory('AuthService' , ['$rootScope', '$http', '$location', function ($rootScope, $http, $location) {
    var user = {
        needsAuthentication: true,
        name: ''
    };

    $rootScope.user = user;
 
    var authService = {};
 
    authService.needsAuthentication = function () {
        var url = baseUrl + 'services/pilotsapp.svc/usersession';
        
        return $http.get(url).then(function (res) {
            if(res)
            {
                if($.cookie('honeywellid'))
                {
                    user.needsAuthentication = res.data.Payload.UserId !== $.cookie('honeywellid');
                }
                else
                {
                    user.needsAuthentication = true;
                }

                if(user.needsAuthentication)
                {
                    $.removeCookie('honeywellid', { path: '/' });
                }
                else
                {
                    user.name = res.data.Payload.UserName; 
                    $rootScope.user = user;
                    var date = new Date();
                    var minutes = 30;
                    date.setTime(date.getTime() + (minutes * 60 * 1000));
                    $.cookie('honeywellid', res.data.Payload.UserId, { expires: date, path: '/' });
                }

                return user.needsAuthentication;
            }
        });
    };

    return authService;
}]);              