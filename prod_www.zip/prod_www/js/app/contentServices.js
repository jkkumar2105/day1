var contentServices = angular.module('contentServices', ['ngResource']);

var baseUrl = 'http://honeywell/'; //LOCAL
if (window.location.host == 'qpilots.honeywell.com') {
    baseUrl = 'https://qaerospace.honeywell.com/'; //QA
} else if (window.location.host == 'pilots.honeywell.com') {
    baseUrl = 'https://aerospace.honeywell.com/'; //PROD
} else if (window.location.host == 'bermudatriangle.dev.laneterralever.com') {
    baseUrl = 'http://107.20.235.94/'; //STAGING
} else if (window.location.host == 'dpilots.honeywell.com') {
    baseUrl = 'https://daerospace.honeywell.com/'; //dev
} else if (window.location.host == 'ca-pilots.honeywell.com') {
    baseUrl = 'https://ca-aerospace.honeywell.com'; //ca
}
contentServices.factory('Slides', ['$resource',
    function ($resource) {
        return $resource(baseUrl + 'services/pilotsapp.svc/slides/', {}, {
            query: { method: 'GET', params: {}, isArray: true }
        });
    }
]);

contentServices.factory('Makes', ['$resource',
    function ($resource) {
        return $resource(baseUrl + 'services/pilotsapp.svc/makes/', {}, {
            query: { method: 'GET', params: {}, isArray: true }
        });
    }
]);

contentServices.factory('Models', ['$resource',
    function ($resource) {
        return $resource(baseUrl + 'services/pilotsapp.svc/models/', {}, {
            query: { method: 'GET', params: {}, isArray: true }
        });
    }
]);

contentServices.factory('FMS', ['$resource',
    function ($resource) {
        return $resource(baseUrl + 'services/pilotsapp.svc/fms/', {}, {
            query: { method: 'GET', params: {}, isArray: true }
        });
    }
]);

contentServices.factory('Aircraft', ['$resource',
    function ($resource) {
        return $resource(baseUrl + 'services/pilotsapp.svc/aircraft/', {}, {
            query: { method: 'GET', params: {}, isArray: false }
        });
    }
]);

contentServices.factory('Document', ['$resource',
    function ($resource) {
        return $resource(baseUrl + 'services/pilotsapp.svc/document/', {}, {
            query: { method: 'GET', params: {}, isArray: true }
        });
    }
]);

contentServices.factory('Products', ['$resource',
    function ($resource) {
        return $resource(baseUrl + 'services/pilotsapp.svc/products/', {}, {
            query: { method: 'GET', params: {}, isArray: true }
        });
    }
]);

contentServices.factory('UserInfo', ['$resource',
    function ($resource) {
        return $resource(baseUrl + 'services/pilotsapp.svc/userinfo/', {}, {
            query: { method: 'GET', params: {}, isArray: false }
        });
    }
]);

contentServices.factory('Services', ['$resource',
    function ($resource) {
        return $resource(baseUrl + 'services/pilotsapp.svc/services/', {}, {
            query: { method: 'GET', params: {}, isArray: true }
        });
    }
]);

contentServices.factory('Form', ['$resource',
    function ($resource) {
        return $resource(baseUrl + 'services/pilotsapp.svc/form/', {}, {
            query: { method: 'GET', params: {}, isArray: true }
        });
    }
]);

contentServices.factory('FeedbackForm', ['$resource',
    function ($resource) {
        return $resource(baseUrl + 'services/pilotsapp.svc/form/feedback', {}, {
            query: { method: 'GET', params: {}, isArray: true }
        });
    }
]);

contentServices.factory('TechnicalForm', ['$resource',
    function ($resource) {
        return $resource(baseUrl + 'services/pilotsapp.svc/form/technical', {}, {
            query: { method: 'GET', params: {}, isArray: true }
        });
    }
]);

contentServices.factory('FormSubmit', ['$resource',
    function ($resource) {
        return $resource(baseUrl + 'services/pilotsapp.svc/formsubmit/', {}, {
            query: { method: 'GET', params: {}, isArray: true }
        });
    }
]);

contentServices.factory('SecurityQuestions', ['$resource',
    function ($resource) {
        return $resource(baseUrl + 'services/pilotsapp.svc/securityquestions/', {}, {
            query: { method: 'GET', params: {}, isArray: true }
        });
    }
]);

contentServices.factory('Newsletters', ['$resource',
    function ($resource) {
        return $resource(baseUrl + 'services/pilotsapp.svc/newsletters/', {}, {
            query: { method: 'GET', params: {}, isArray: true }
        });
    }
]);

contentServices.factory('News', ['$resource',
    function ($resource) {
        return $resource(baseUrl + 'services/pilotsapp.svc/news/', {}, {
            query: { method: 'GET', params: {}, isArray: true }
        });
    
    }
]);

contentServices.factory('Events', ['$resource',
    function ($resource) {
        return $resource(baseUrl + 'services/pilotsapp.svc/events/', {}, {
            query: { method: 'GET', params: {}, isArray: true }
        });
    }
]);

contentServices.factory('Search', ['$resource',
    function ($resource) {
        return $resource(baseUrl + 'services/pilotsapp.svc/search/', {}, {
            query: { method: 'GET', params: {}, isArray: true }
        });
    }
]);