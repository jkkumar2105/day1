pilotsApp.controller('MyGDCHomeViewCtrl', ['$scope', '$rootScope', 'Slides', '$location', 'Slider', function($scope, $rootScope, Slides, $location, Slider) {
    $rootScope.pageTitle = 'My GDC';
    
    $scope.slides = [];
    $scope.params = {};
    $scope.params.itemid = '{18E5C351-3D07-4633-8F7C-F08F5758F224}';;
    
    $scope.load_slides = function() {
        $.isLoading({ text: 'Loading', position:   'overlay' });
    
        Slides.query($scope.params, function (data) {
            $.isLoading('hide');
            
            if (data.length > 0) {
                $scope.numStaticSlides = 0;
                $scope.slides = data;
                setTimeout(function () {
                  Slider.slider.reloadSlider();
                },1000);
            }
        });
    };
    
    $scope.load_slides();
    
    ga('send', 'pageview', { 'page': $location.path(), 'title': $rootScope.pageTitle });
}]);

pilotsApp.controller('MyGDCInfoViewCtrl', ['$scope', '$location', '$rootScope', function($scope, $location, $rootScope) {
    var leadData = {
        'description': 'GDC- Information Requested'
    };
          
    $.ajax({
        url: baseUrl + 'services/pilotsapp.svc/sflead',
        type: "POST",
        data: leadData,
        xhrFields: {
            withCredentials: true
        }
    });
    
    ga('send', 'pageview', { 'page': $location.path(), 'title': $rootScope.pageTitle });
}]);
