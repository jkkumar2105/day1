pilotsApp.config(['$routeProvider',
    function($routeProvider) {
        $routeProvider.
            //My Aircraft
            when('/myac/', {
                templateUrl: '/partials/myac/home.html',
                controller: 'HomeViewCtrl',
                requireLogin: false,
                showLogo: true,
                hideLogoText: false,
                hideFooter: true
            })
            .when('/myac/register/', {
                templateUrl: '/partials/myac/register.html',
                controller: 'RegisterViewCtrl',
                requireLogin: false,
                hideFooter: true
            })
            .when('/myac/register/thanks/', {
                templateUrl: '/partials/myac/thanks.html',
                controller: 'ThanksViewCtrl',
                requireLogin: false,
                hideFooter: true
            })
            .when('/myac/logout/', {
                templateUrl: '/partials/myac/logout.html',
                controller: 'LogoutViewCtrl',
                requireLogin: false
            })
            .when('/myac/makes/', {
                templateUrl: '/partials/myac/makes.html',
                controller: 'MakesViewCtrl',
                requireLogin: true,
                pageTitle: 'Select Manufacturer (Step 1 of 3)'
            })
            .when('/myac/models/:makeid/', {
                templateUrl: '/partials/myac/models.html',
                controller: 'ModelsViewCtrl',
                requireLogin: true,
                pageTitle: 'Select Model (Step 2 of 3)'
            })
            .when('/myac/fms/:modelid/', {
                templateUrl: '/partials/myac/fms.html',
                controller: 'FMSViewCtrl',
                requireLogin: true,
                pageTitle: 'Select FMS Version (Step 3 of 3)'
            })
            .when('/myac/aircraft/', {
                templateUrl: '/partials/myac/aircraft.html',
                controller: 'AircraftViewCtrl',
                requireLogin: true,
                showLogo: true,
                hideLogoText: true
            })
            .when('/myac/aircraft/:fmsid/', {
                templateUrl: '/partials/myac/aircraft.html',
                controller: 'AircraftViewCtrl',
                requireLogin: true,
                showLogo: true,
                hideLogoText: true
            })
            .when('/myac/aircraft/:fmsid/:modelid/', {
                templateUrl: '/partials/myac/aircraft.html',
                controller: 'AircraftViewCtrl',
                requireLogin: true,
                showLogo: true,
                hideLogoText: true
            })
            .when('/myac/search/', {
              templateUrl: '/partials/myac/search.html',
              controller: 'SearchViewCtrl',
              requireLogin: true
            })
            .when('/myac/search/:query', {
                templateUrl: '/partials/myac/search.html',
                controller: 'SearchViewCtrl',
                requireLogin: true
            })
            .when('/privacy/', {
                templateUrl: '/partials/general/privacy.html',
                controller: 'ContentViewCtrl',
                pageTitle: 'Privacy Policy',
                requireLogin: false,
                hideFooter: true
            })
            //My GDC
            .when('/gdc/', {
                templateUrl: '/partials/gdc/home.html',
                controller: 'MyGDCHomeViewCtrl',
                requireLogin: true
            })
            .when('/gdc/information', {
                templateUrl: '/partials/gdc/information.html',
                controller: 'MyGDCInfoViewCtrl',
                requireLogin: true
            })
            //FMS Newsletter
            .when('/fms/', {
                templateUrl: '/partials/fms/home.html',
                controller: 'FMSHomeViewCtrl',
                requireLogin: true,
                hideFooter: false
            })
            .when('/fms/:id', {
                templateUrl: '/partials/fms/details.html',
                controller: 'NewsletterContentsCtrl',
                requireLogin: true,
                hideFooter: false
            })
            .when('/fms/:id/:article_id', {
                templateUrl: '/partials/fms/newsletter.html',
                controller: 'NewsletterViewCtrl',
                requireLogin: true,
                hideFooter: false
            })
            //Events
            .when('/event/', {
                templateUrl: '/partials/event/home.html',
                controller: 'EventsHomeViewCtrl',
                requireLogin: true
            })
            .when('/event/:eventid', {
                templateUrl: '/partials/event/details.html',
                controller: 'EventsDetailViewCtrl',
                requireLogin: true
            })
            //News
            .when('/news/', {
                templateUrl: '/partials/news/home.html',
                controller: 'NewsHomeViewCtrl',
                requireLogin: true
            })
            .when('/news/:newsid', {
                templateUrl: '/partials/news/details.html',
                controller: 'NewsDetailViewCtrl',
                requireLogin: true
            })
            //Contact
            .when('/contact/', {
                templateUrl: '/partials/contact/home.html',
                controller: 'ContactUsViewCtrl',
                requireLogin: true
            })
            .when('/contact/thanks/', {
                templateUrl: '/partials/contact/thanks.html',
                controller: 'ThanksViewCtrl',
                requireLogin: true
            })                        
            //General
            .when('/terms/', {
                templateUrl: '/partials/general/terms.html',
                controller: 'ContentViewCtrl',
                pageTitle: 'Terms & Conditions',
                requireLogin: false,
                hideFooter: true
            })
            .otherwise({
                redirectTo: '/myac/'
            });
  }]);