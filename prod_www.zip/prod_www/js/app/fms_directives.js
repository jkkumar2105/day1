'use strict';

pilotsApp.factory('Newsletter', [ '$location', '$sce', 'Newsletters', function ($location, $sce, Newsletters) {

    function Newsletter() {
    }

    /* Newsletter Data */
    Newsletter.current = null;
    Newsletter.newsletters = null;
    
    Newsletter.load_newsletters = function(callback) {
        $.isLoading({ text: 'Loading', position:   'overlay' });
        
        var params = [];
        
        Newsletters.query(params, function (data) {
            if (data.length > 0 && data[0].Status != 'Error') {
                var i = 0, count = data.length;
                for (i = 0; i < count; i++) {
                    var j = 0, jCount = data.length;
                    for (j = 0; j < jCount; j++) {
                        data[i].children[j].content = $sce.trustAsHtml(data[i].children[j].content);
                    }
                }
                Newsletter.newsletters = data;
                Newsletter.current = data[0];
                
                if (callback) {
                    callback(data);
                }
            }

            $.isLoading('hide');
        }, function (data) {
            $.isLoading('hide');
            alert('Failed to load Newsletters, Please try again.')
        });
    }
    
    /* Open a newsletter by id */
    Newsletter.viewNewsletter = function (id) {
        if (typeof(id) === 'undefined') {
            $location.path("/fms/");
        } else {
            $location.path("/fms/" + id);
        }
    };

    /* View Article by newsletter and article id */
    Newsletter.viewArticle = function (id, article_id) {
        if (typeof(id) === 'undefined' || typeof(article_id) === 'undefined') {
            $location.path("/fms/");
        } else {
            $location.path("/fms/" + id + "/" + article_id);
        }
    };

    /* Get newsletter by id */
    Newsletter.getNewsletterById = function (id) {
        
        for (var i = 0; i < Newsletter.newsletters.length; i++) {
            var ns = Newsletter.newsletters[i];
            if (Newsletter.isValid(ns) && ns.id === id) {
                return ns;
            }
        }
        return null;
    };

    /* Get article by newsletter and article id */
    Newsletter.getArticleById = function (id, article_id) {
        var ns = Newsletter.getNewsletterById(id);

        for (var i = 0; i < ns.children.length; i++) {
            var article = ns.children[i];
            if (article.id === article_id) {
                return article;
            }
        }
        return null;
    };

    Newsletter.isValid = function (ns) {
        return (ns && ns.hasOwnProperty('id'));
    };

    /* Receive for newsletter */
    Newsletter.receiveByEmail = function () {
        var url = 'https://contactaero.honeywell.com/GlobalCustomerCareWeb/pilotinformation.do?SFDC=true';
        window.open(url, '_blank');
    };

    return Newsletter;

}]).directive('ltAbsImage', ['$timeout', '$compile', function ($timeout, $compile) {
    return {
        restrict: 'A',
        link: function (scope, elem, attrs) {              
            var baseUrl = window.baseUrl;
            if (elem.src.indexOf("http") === -1) {
                elem.src = baseUrl + elem.src;
            }
        }
    };
}]).directive('ltAbsContentImages', ['$timeout', '$compile', function ($timeout, $compile) {
    return {
        restrict: 'A',
        transclude: true,
        link: function (scope, elem, attrs) {
            $timeout(function(){                
                var baseUrl = window.baseUrl;
                var html = elem.html().replace(/(src=")(?!http)(.*?)"/gi, '$1' + baseUrl + '$2"');
                var e = $compile(html)(scope);
                elem.replaceWith(e);
            });
        }
    };
}]).directive('ellipsis', [ '$timeout', function ($timeout) {
return {
    restrict: 'AE',
    link: function (scope, ele) {
        $timeout(function () {
            $(ele).dotdotdot();
        });
    }
}
}]).directive('newsletterLarge', [ 'Newsletter', function (Newsletter) {
    return {
        restrict: 'AE',
        templateUrl: '/templates/newsletter-large.html',
        scope: {
            newsletter: '=newsletter'
        },
        replace: true,
        link: function (scope, ele, attrs) {
            scope.moreNewsletter = typeof attrs['fullNewsletter'] === 'undefined';
            scope.title = attrs.title || 'Current Newsletter';
            scope.actions = Newsletter;
        }
    }
}]).directive('newsletterSmall', [ 'Newsletter', function (Newsletter) {
    return {
        restrict: 'AE',
        templateUrl: '/templates/newsletter-small.html',
        scope: {
            newsletter: '=newsletter'
        },
        replace: true,
        link: function (scope) {
            scope.actions = Newsletter;
        }
    }
}]);