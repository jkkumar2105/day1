pilotsApp.controller('ContactUsViewCtrl', ['$location','$scope', '$sce', '$rootScope', '$timeout', 'Form', 'FeedbackForm', 'TechnicalForm', 'FormSubmit', 'Products', 'Services', 'UserInfo', 'Progpilots',  function($location, $scope, $sce, $rootScope, $timeout, Form, FeedbackForm, TechnicalForm, FormSubmit, Products, Services, UserInfo, Progpilots) {
    $rootScope.pageTitle = 'Contact Us';
        //Added by Arvind to hold Back button changes
    $rootScope.breadcrumbTitle = 'Back';
    $.isLoading({ text: 'Loading', position:   'overlay' });
    
    $scope.form = {};
    $scope.products = {};
    $scope.services = {};
    $scope.sendparams = {};
    $scope.params = {};
    //Added by Arvind
    $scope.progpilots = {};
    $scope.selectedPilot = null;
    $scope.showContactSelectionDialog = false;

    $scope.load_products = function(form_type){
        $scope.params.itemid = '{BD80C330-8868-4276-A7EC-7445745F698D}';

        Form.query($scope.params, function (data) {
            if (data.length > 0) {
                $scope.form = data[0];
                $scope.form.description = $sce.trustAsHtml($scope.form.description);
                $scope.formId = $scope.form.id;
            }
            
            setTimeout(function () {
              $.validate({
                form : '#contact_form',
                modules: 'file'
              });
            }, 1000);
            $.isLoading('hide');
        });

        Products.query({}, function (data) {
            if (data.length > 0) {
                $scope.products = data;
            }
        });
        
        Services.query({}, function (data) {
            if (data.length > 0) {
                $scope.services = data;
            }
        });
        ///Added by Arvind to get the Program pilots contact
        Progpilots.query({}, function (data) {
            if (data.length > 0) {
                $scope.progpilots = data;
            }
        });
        
        if(form_type == 'question')
        {
            UserInfo.query({}, function(data){
                if(data.Status == "OK")
                {
                    $timeout(function() {
                        setValues(data.Payload);
                    }, 100);
                }
            });
        }
        
    };
    
    $scope.showTab = function($event, id){
        if($('.active_tab').attr('id') !== id){
            $('.active_tab').fadeOut( 'fast', function () {
                $(this).removeClass('active_tab');
                if(id == 'questions_form'){
                    $scope.load_products("question");
                }
                $('#' + id).fadeIn().addClass('active_tab');
            });
            
            $('.contact_btn.active').removeClass('active');
            
            var $target = $($event.delegateTarget);
            $target.addClass('active');
            
        }
        $scope.dform_show = false;
        $scope.services_show = false;
        $scope.products.selectedItem = {};
        $scope.services.selectedItem = {};
    };
    
    $scope.services_show = false;
    
    //Handle form change
    $scope.changeForm = function (form_type) {
        $scope.dform_show = false;
        
        if (form_type == "feedback" || form_type == "technical") {
            //Services selected
            if ($scope.products.selectedItem.name.indexOf('Services') != -1) {
                if ($scope.services_show === false) {
                    $scope.params.itemid = null;
                    $scope.services_show = true;
                } else {
                    $scope.params.itemid = $scope.services.selectedItem.id;
                }
                
                $scope.doYouUse = true;
            } else {
                $scope.services_show = false;
                $scope.params.itemid = $scope.products.selectedItem.id;
                $scope.doYouUse = true;
            }
        } else {
            $scope.services_show = false;
            $scope.params.itemid = $scope.products.selectedItem.id;
        }
        
        if ($scope.params.itemid) {
            if (form_type == "feedback") {
                FeedbackForm.query($scope.params, function (data) {
                    if (data.length > 0) {
                        $scope.form = data[0];
                        $scope.form.description = $sce.trustAsHtml($scope.form.description);
                        $scope.formId = $scope.form.id;
                      setTimeout(function () {
                        $.validate({
                          form : '#product_form',
                          modules: 'file'
                        });
                      }, 1000);
                    }
                    $scope.dform_show = true;
                });
            } else {
                TechnicalForm.query($scope.params, function (data) {
                    if (data.length > 0) {
                        $scope.form = data[0];
                        $scope.form.description = $sce.trustAsHtml($scope.form.description);
                        $scope.formId = $scope.form.id;
                      setTimeout(function () {
                        $.validate({
                          form : '#technicals_form',
                          modules: 'file'
                        });
                      }, 1000);
                    }
                    $scope.dform_show = true;
                });
            }
        }
    };

    $scope.changeUse = function (thismodel) {
        $scope.doYouUse = $scope.doYouUse;
    };
  
  //Added by Arvind Starts here  
    $scope.changeUseContact = function (thismodel) {
        $scope.doYouUseContat = $scope.doYouUseContat;
        $scope.showContactSelectionDialog = $scope.doYouUseContat;;

        if ( $scope.doYouUseContat) {
            $scope.doYouUsetest = true;
            $scope.doYouUseemail = true;             
        } else {
            $scope.selectedPilot = null;
            $scope.doYouUsetest = false;
            $scope.showContactSelectionDialog = false;
            $scope.showSelEmail = false;
            $scope.doYouUseemail = false;
        }
    };

    $scope.closePPemail = function () {
        if ( $scope.selectedPilot ) {
            $scope.doYouUseContat = true;
        } else {
            $scope.doYouUseContat = false;
        }

        $scope.doYouUsetest = false;
        $scope.showContactSelectionDialog = false;
        $scope.showSelEmail = false;
    };

     $scope.editPPemail= function () {
         $scope.doYouUsetest = true;
         $scope.doYouUseemail = false;
         $scope.showContactSelectionDialog = true;
    };
    //Added by Arvind
    $scope.selProgpilot = function(pilot) {
        //alert($scope.doYouUse);
        $scope.selectedPilot = pilot;
        
        console.log( $scope.selectedPilot );
        
        $scope.editimg = "images/edit.png"
        $scope.doYouUsetest = false;
        $scope.doYouUseemail = true;
        $scope.showContactSelectionDialog = false;
    };
  
	
	 $scope.showThanks = function() {
        window.location = '#/contact/thanks/';
    }; 
    
    $scope.submitForm = function($event, theform){
        $event.preventDefault();
        var formId = '#' + theform;
        
        var checkForm = theform != 'product_form' || $scope.doYouUse ? true : false;
        
        var formValid = checkForm ? $(formId).isValid() : true;

        if (formValid === true) {
            $.isLoading({ text: 'Submitting Form', position:   'overlay' });
            
            //var url = baseUrl + 'services/pilotsapp.svc/form?itemId=' + $scope.params.itemid;
            var url = baseUrl + 'services/pilotsapp.svc/form?itemId=' + $scope.formId;
            var formData = new FormData();

            $(formId).find('input').each(function(k,v) {
                if(v.type == "file") {
                    formData.append(v.name,v.files[0]);
                } else {
                    formData.append(v.name,v.value);
                }
            });
            $(formId).find('textarea').each(function(k,v) {
                formData.append(v.name,v.value);
            });
            $(formId).find('select').each(function(k,v) {
                formData.append(v.name,v.value);
            });
            
            $.ajax({
                url:url,
                type:'POST',
                data: formData,
                xhrFields: {
                    withCredentials: true
                },
                processData:false,
                contentType:false
            }).success(function(data) {
                if(data.Status === "OK") {
                    var action = 'Submit Question';
                    var formName = theform;
                    if (formName != 'contact_form') {
                        
                        if(formName ===  'product_form'){
                            action = 'Submit Feedback';
                        } else {
                            action = 'Submit Technical Issue';
                        }
                        formName = $scope.products.selectedItem ? $scope.products.selectedItem.name : '';
                        formName += $scope.services.selectedItem ? ('  -  ' + $scope.products.selectedItem) : '';   
                    } else {
                        formName = 'Submit Question';
                    }
                       
                    ga('send', 'event', 'Contact', action, formName);
                    $scope.showThanks();
                } else {
                    alert(data.Message);
                }
            }).error(function() {
                alert("There was an error submitting your request");
            }).complete(function() {
                $.isLoading('hide');
            });

        } else {
            alert('Please verifty all information is correct and mandatory fields are completed and resubmit the form');
        }
    };
    
    $('body').on('change', 'input[type="file"]', function(){
        $('.clear_btn').removeClass('hide');
    });

    $scope.load_products("question");
}]);

//THANK YOU VIEW
pilotsApp.controller('ThanksViewCtrl', ['$scope', '$rootScope', function($scope, $rootScope) {
    $rootScope.pageTitle = 'Thanks';
 }]);

function clearFileUpload(name) {
    $('input[name="' + name + '"]').each(function(){
        $(this).val('');
        $(this).nextAll('.form-error').remove();
        $('.clear_btn').addClass('hide');
    });
}

function setValues(values)
{
    $('input[name="first_name"]').val(values.FirstName);
    $('input[name="last_name"]').val(values.LastName);
    $('input[name="email"]').val(values.Email);
    $('input[name="phone"]').val(values.Phone);
    $('input[name="company"]').val(values.Company);
}
