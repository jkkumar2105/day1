pilotsApp.controller('NewsHomeViewCtrl', ['$scope', '$rootScope', '$location', 'News', function($scope, $rootScope, $location, News) {
    $rootScope.pageTitle = 'News';

    $scope.load_news = function() {
        $.isLoading({ text: 'Loading', position:   'overlay' });
        
        News.query($scope.params, function (data) {
            if (data.length > 0 && data[0].Status != "Error") {
                $scope.featured = data[0];
                var dataCopy = angular.copy(data);
                dataCopy.shift();
                $scope.news = dataCopy;
            }
            
            $.isLoading('hide');
        }, function (data) {
            $.isLoading('hide');
            alert('Failed to load News, Please try again.')
        });
    }
    
    $scope.load_news();
    
    ga('send', 'pageview', { 'page': $location.path(), 'title': $rootScope.pageTitle });
}]);

pilotsApp.controller('NewsDetailViewCtrl', ['$scope', '$rootScope', '$routeParams', 'News', function($scope, $rootScope, $routeParams, News) {
	$rootScope.pageTitle = 'News';

    $scope.load_news_article = function() {
        $.isLoading({ text: 'Loading', position:   'overlay' });
        
        $scope.params = {};
        $scope.params.itemId = $routeParams.newsid;


        News.query($scope.params, function (data) {
            if (data.length > 0 && data[0].Status != "Error") {
                $scope.article = data[0];
            }
            
            $.isLoading('hide');

            ga('send', 'pageview', { 'page': $location.path(), 'title': $rootScope.pageTitle + ' - ' + $scope.article.headline });
        }, function (data) {
            $.isLoading('hide');
            alert('Failed to load Article, Please try again.')

            ga('send', 'pageview', { 'page': $location.path(), 'title': $rootScope.pageTitle });
        });
    }
    
    $scope.load_news_article();    
}]);
