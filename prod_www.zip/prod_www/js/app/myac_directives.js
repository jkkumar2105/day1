'use strict';

pilotsApp.factory('Slider', [ function () {
    function Slider() {}

    Slider.init = function() {

        Slider.activeClass = '.bx-pager-link';
        Slider.dataSlide   = '.bx-pager-link[data-slide-index=';

        Slider.slider = $('.slides').bxSlider({
            controls: false,
            pager: false,
            onSlideAfter: function($slideElement, oldIndex, newIndex){
                if (oldIndex == 0 && newIndex == 1) {
                    $('.login_btn').fadeIn();
                }
                if (newIndex == 0) {
                    $('.login_btn').fadeOut();
                }
                Slider.activeSlide(newIndex);
            }
        });
    };

    Slider.swipeLeft = function() {
        Slider.slider.goToNextSlide();
    };

    Slider.swipeRight = function () {
        Slider.slider.goToPrevSlide();
    };

    Slider.changeSlide = function (n) {
        Slider.activeSlide(n);
        Slider.slider.goToSlide(n);
    };

    Slider.activeSlide = function (i) {
        $(Slider.activeClass).removeClass('active');
        $(Slider.dataSlide+'"'+i+'"]').addClass('active');
    };

    return Slider;

}]).directive('slides', [ 'Slider', function (Slider) {
    /* bxSlider */
    return {
        restrict: 'A',
        link: function (scope) {
            if (scope.$last === true) {
                Slider.init();
            }
        }
    }
}]).directive('slideControls', [ 'Slider', function (Slider) {
    /* Overridden controls of bxSlider to enable slide on controls */
    return {
        restrict: 'AE',
        templateUrl: '/templates/slide-controls.html',
        link: function (scope) {
            angular.extend(scope, Slider);
        }
    }
}]).directive('documentItem', [ function () {
    return {
        restrict: 'E',
        templateUrl: '/templates/document-item.html',
        controller: [ '$scope', function ($scope) {
            $scope.docClick = function(doc) {
               
                //Register as read
                var val = doc.pubnumber ? doc.pubnumber : 'no_pub_number';
                $.jStorage.set(doc.id, val);
                
                var title = doc.pubnumber ? doc.pubnumber : doc.name;

                //Record lead data
                if (doc.salesbulletin) {
                    var leadData = {
                        'description': title
                    };
                          
                    $.ajax({
                        url: baseUrl + 'services/pilotsapp.svc/sflead',
                        type: "POST",
                        data: leadData,
                        xhrFields: {
                            withCredentials: true
                        }
                    });
                } 
                
                doc.read = true;
                doc.newdoc = false;
                doc.updated = false;
                
                var path = 'services/pilotsapp.svc/document?itemid=' + doc.id;
                ga('send', 'pageview', { 'page': '/'+path, 'title': title });
                ga('send', 'event', 'Downloads', 'View Document', title);
                
                if (doc.documentlink.indexOf('honeywell') == -1) {
                    window.open(doc.documentlink);
                } else {
                    window.open(baseUrl + path);                    
                }
            }
        }]
    }
}]).directive('docStatus', [function () {
    return {
        restrict: 'A',
        link: function (scope) {
            var doc = scope.document;
            var docDate = doc.revisiondate ? doc.revisiondate : doc.publishdate;
            
            var pubNum = $.jStorage.get(doc.id);
            doc.read =  pubNum ? true : false;
                
            if (docDate && docDate.length > 0) {
                var timeStamp = (new Date(docDate)).getTime();
                var nowTime = (new Date()).getTime();
                var daysSince = ((nowTime - timeStamp) / 1000) / 86400;
                
                var revDate = doc.revisiondate ? (new Date(doc.revisiondate)).getTime() : (new Date(docDate)).getTime();
                var pubDate = doc.publishdate ? (new Date(doc.publishdate)).getTime() : (new Date(docDate)).getTime();
                
                if(daysSince < 30 && daysSince >= -1) {
                    if (pubDate == timeStamp) {
                        doc.newdoc = true;
                    } else if (revDate > pubDate) {
                        doc.updated = true;
                        if (doc.read) {
                            if ( pubNum != doc.pubnumber) {
                                doc.read = false;
                            } else {
                                doc.updated = false;  
                            }                            
                        }
                    }
                }
            }
        }
    }
}]);