pilotsApp.controller('EventsHomeViewCtrl', ['$scope', '$rootScope', '$location', 'Events', function($scope, $rootScope, $location, Events) {
    $rootScope.pageTitle = 'Events';
    
    $scope.load_events = function() {
        $.isLoading({ text: 'Loading', position:   'overlay' });
        
        Events.query($scope.params, function (data) {
            if (data.length > 0 && data[0].Status != "Error") {
                var i= 0, count = data.length;
                for (i = 0; i < count; i++) {
                    data[i].enddate = (data[i].enddate && data[i].startdate != data[i].enddate) ? new Date(data[i].enddate) : null;
                    data[i].startdate = data[i].startdate ? new Date(data[i].startdate) : null;
                }
                
                $scope.events = data;
            }
            
            $.isLoading('hide');
        }, function (data) {
            $.isLoading('hide');
            alert('Failed to load Events, Please try again.')
        });
    }
    
    $scope.load_events();
    
    ga('send', 'pageview', { 'page': $location.path(), 'title': $rootScope.pageTitle });
}]);

pilotsApp.controller('EventsDetailViewCtrl', ['$scope', '$rootScope', '$routeParams', '$location', '$sce', 'Events', function($scope, $rootScope, $routeParams, $location, $sce, Events) {
	$rootScope.pageTitle = 'Events';
    
    $scope.load_event = function() {
        $.isLoading({ text: 'Loading', position:   'overlay' });
        
        $scope.params = {};
        $scope.params.itemid = $routeParams.eventid;
        
        Events.query($scope.params, function (data) {
            $.isLoading('hide');

            if (data.length > 0 && data[0].Status != "Error") {
                data[0].enddate = (data[0].enddate && data[0].startdate != data[0].enddate) ? new Date(data[0].enddate) : null;
                data[0].startdate = data[0].startdate ? new Date(data[0].startdate) : null;

                $scope.event = data[0];
            }
    
            ga('send', 'pageview', { 'page': $location.path(), 'title': $rootScope.pageTitle + ' - ' + $scope.event.title });
        }, function (data) {
            $.isLoading('hide');
            alert('Failed to load Event, Please try again.')

            ga('send', 'pageview', { 'page': $location.path(), 'title': $rootScope.pageTitle });
        });
    }
    
    $scope.load_event();
}]);
