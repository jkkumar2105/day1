'use strict';

pilotsApp.controller('FMSHomeViewCtrl', ['$scope', '$location', '$rootScope', 'Newsletter', 'Newsletters', function ($scope, $location, $rootScope, Newsletter, Newsletters) {

    $rootScope.pageTitle = 'Direct-TO Newsletter';

    $scope.newsletter = Newsletter;

    $scope.newsletter.load_newsletters(function(data){
        var dataCopy = angular.copy(data);
        dataCopy.shift();
        $scope.newsletters = dataCopy;
    });
    
    ga('send', 'pageview', { 'page': $location.path(), 'title': $rootScope.pageTitle });
}]);

pilotsApp.controller('NewsletterContentsCtrl', ['$scope', '$location', '$rootScope', '$routeParams', 'Newsletter', 'Newsletter', function ($scope, $location, $rootScope, $routeParams, Newsletter, Newsletters) {

    $rootScope.pageTitle = 'Direct-TO Newsletter';

    $scope.newsletter = Newsletter;

    if ($scope.newsletter.newsletters === null) {
        $scope.newsletter.load_newsletters(function(data){
            $scope.contents_newsletter = $scope.newsletter.getNewsletterById($routeParams.id);
            $scope.contents_newsletter.children[0].publishdate = Date.parse($scope.contents_newsletter.children[0].publishdate);
        });
    } else {
        $scope.contents_newsletter = $scope.newsletter.getNewsletterById($routeParams.id);
        $scope.contents_newsletter.children[0].publishdate = Date.parse($scope.contents_newsletter.children[0].publishdate);
    }
    
    var newsletterTitle = $scope.contents_newsletter ? $scope.contents_newsletter.title : '';
    ga('send', 'pageview', { 'page': $location.path(), 'title': $rootScope.pageTitle + ' - ' + newsletterTitle  });
}]);

pilotsApp.controller('NewsletterViewCtrl', ['$scope', '$location', '$rootScope', '$routeParams', 'Newsletter', function ($scope, $location, $rootScope, $routeParams, Newsletter) {

    $rootScope.pageTitle = 'Direct-TO Newsletter';

    $scope.newsletter = Newsletter;

    if ($scope.newsletter.newsletters === null) {
        $scope.newsletter.load_newsletters(function(data){
            $scope.current_article = $scope.newsletter.getArticleById($routeParams.id, $routeParams['article_id']);
        });
        
    } else {
        $scope.current_article = $scope.newsletter.getArticleById($routeParams.id, $routeParams['article_id']);
    }

    var articleTitle = $scope.current_article ? $scope.current_article.title : '';
    ga('send', 'pageview', { 'page': $location.path(), 'title': $rootScope.pageTitle + ' - ' + articleTitle  });
}]);